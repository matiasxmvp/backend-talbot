#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script para verificar el estado de la base de datos
Este script ayuda a diagnosticar problemas de conexión y tablas
"""

import os
import sys
from sqlalchemy import create_engine, text, inspect
from sqlalchemy.exc import SQLAlchemyError
from app.core.config import settings
from app.db.database import engine, Base

def check_database_connection():
    """Verificar la conexión a la base de datos"""
    print("🔍 DIAGNÓSTICO DE BASE DE DATOS")
    print("=" * 50)
    
    # Mostrar configuración
    print(f"📊 URL de base de datos: {settings.database_url}")
    print(f"🌍 Entorno: {os.getenv('ENVIRONMENT', 'development')}")
    print()
    
    try:
        # Probar conexión
        print("🔗 Probando conexión a la base de datos...")
        with engine.connect() as connection:
            result = connection.execute(text("SELECT 1"))
            print("✅ Conexión exitosa")
            
            # Verificar tipo de base de datos
            db_type = engine.dialect.name
            print(f"🗄️  Tipo de base de datos: {db_type}")
            
            # Listar tablas existentes
            inspector = inspect(engine)
            tables = inspector.get_table_names()
            print(f"📋 Tablas encontradas ({len(tables)}):")
            
            if tables:
                for table in tables:
                    print(f"   - {table}")
                    # Contar registros en cada tabla
                    try:
                        count_result = connection.execute(text(f"SELECT COUNT(*) FROM {table}"))
                        count = count_result.scalar()
                        print(f"     Registros: {count}")
                    except Exception as e:
                        print(f"     Error al contar: {str(e)}")
            else:
                print("   ❌ No se encontraron tablas")
                
            print()
            
            # Verificar tabla users específicamente
            if 'users' in tables:
                print("👤 Verificando tabla users:")
                try:
                    users_result = connection.execute(text("SELECT username, email, role FROM users LIMIT 5"))
                    users = users_result.fetchall()
                    print(f"   Usuarios encontrados: {len(users)}")
                    for user in users:
                        print(f"   - {user[0]} ({user[1]}) - {user[2]}")
                except Exception as e:
                    print(f"   ❌ Error al consultar users: {str(e)}")
            else:
                print("❌ Tabla 'users' no existe")
                
    except SQLAlchemyError as e:
        print(f"❌ Error de SQLAlchemy: {str(e)}")
        return False
    except Exception as e:
        print(f"❌ Error general: {str(e)}")
        return False
        
    return True

def check_models():
    """Verificar que los modelos estén correctamente importados"""
    print("\n🏗️  VERIFICANDO MODELOS")
    print("=" * 30)
    
    try:
        # Importar modelos
        from app.models.user import User
        from app.models.refresh_token import RefreshToken
        from app.models.hotel import Hotel
        
        print("✅ Modelos importados correctamente:")
        print(f"   - User: {User.__tablename__}")
        print(f"   - RefreshToken: {RefreshToken.__tablename__}")
        print(f"   - Hotel: {Hotel.__tablename__}")
        
        # Verificar metadatos
        tables_in_metadata = list(Base.metadata.tables.keys())
        print(f"\n📋 Tablas en metadatos ({len(tables_in_metadata)}):")
        for table in tables_in_metadata:
            print(f"   - {table}")
            
        return True
        
    except Exception as e:
        print(f"❌ Error al importar modelos: {str(e)}")
        return False

def main():
    """Función principal"""
    print("🏨 TALBOT HOTELS - Diagnóstico de Base de Datos\n")
    
    # Verificar modelos
    models_ok = check_models()
    
    # Verificar conexión
    connection_ok = check_database_connection()
    
    print("\n" + "=" * 50)
    if models_ok and connection_ok:
        print("✅ Diagnóstico completado - Todo parece estar bien")
    else:
        print("❌ Se encontraron problemas - Revisar logs arriba")
        sys.exit(1)

if __name__ == "__main__":
    main()