import psycopg2
from app.core.config import settings

def check_enum_and_users():
    try:
        # Conectar a la base de datos
        conn = psycopg2.connect(settings.database_url)
        cursor = conn.cursor()
        
        print("=== Verificando valores del enum userrole ===")
        cursor.execute("SELECT unnest(enum_range(NULL::userrole))")
        enum_values = cursor.fetchall()
        for value in enum_values:
            print(f"- {value[0]}")
        
        print("\n=== Verificando usuarios existentes ===")
        cursor.execute("SELECT username, role FROM users ORDER BY username")
        users = cursor.fetchall()
        for user in users:
            print(f"Usuario: {user[0]}, Rol: {user[1]}")
        
        print("\n=== Verificando si existe usuario 'admin' ===")
        cursor.execute("SELECT username, role FROM users WHERE username = 'admin'")
        admin_user = cursor.fetchone()
        if admin_user:
            print(f"Usuario admin encontrado: {admin_user[0]}, Rol: {admin_user[1]}")
        else:
            print("No se encontró usuario 'admin'")
        
        cursor.close()
        conn.close()
        
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    check_enum_and_users()