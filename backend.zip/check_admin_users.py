#!/usr/bin/env python3
# Script para verificar usuarios ADMINISTRADOR

import sys
import os
from sqlalchemy import create_engine, text

# Agregar el directorio raíz al path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from app.core.config import settings

def check_admin_users():
    """Verificar si existen usuarios con rol ADMINISTRADOR"""
    try:
        engine = create_engine(settings.database_url)
        
        with engine.connect() as connection:
            print("🔍 Verificando valores del enum userrole...")
            
            # Verificar valores del enum
            enum_values = connection.execute(text("""
                SELECT unnest(enum_range(NULL::userrole))
            """)).fetchall()
            
            print("\n📋 Valores disponibles en el enum userrole:")
            for value in enum_values:
                print(f"  - '{value[0]}'")
            
            print("\n🔍 Buscando usuarios por cada rol...")
            
            # Mostrar todos los usuarios y sus roles
            all_users = connection.execute(text("""
                SELECT username, role::text, full_name, is_active
                FROM users 
                ORDER BY role::text, username
            """)).fetchall()
            
            if all_users:
                print(f"\n👥 Todos los usuarios en la base de datos ({len(all_users)}):")
                current_role = None
                for username, role, full_name, is_active in all_users:
                    if role != current_role:
                        print(f"\n🏷️  Rol: {role}")
                        current_role = role
                    status = "✅ Activo" if is_active else "❌ Inactivo"
                    print(f"    - {username} - {full_name} [{status}]")
            else:
                print("\n❌ No se encontraron usuarios en la base de datos")
                
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    check_admin_users()