#!/usr/bin/env python3
# Script temporal para verificar los valores del enum userrole en la base de datos

import psycopg2
from app.core.config import settings

def check_enum_values():
    """Verificar los valores del enum userrole en PostgreSQL"""
    try:
        # Conectar a la base de datos
        conn = psycopg2.connect(settings.database_url)
        cur = conn.cursor()
        
        # Consultar los valores del enum
        cur.execute("SELECT unnest(enum_range(NULL::userrole))")
        values = cur.fetchall()
        
        print("Valores del enum 'userrole' en la base de datos:")
        print("=" * 50)
        for value in values:
            print(f"- {value[0]}")
        
        # Cerrar conexión
        cur.close()
        conn.close()
        
    except Exception as e:
        print(f"Error al consultar la base de datos: {e}")

if __name__ == "__main__":
    check_enum_values()