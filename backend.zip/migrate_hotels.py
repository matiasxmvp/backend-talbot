# migrate_hotels.py - Script para migrar hoteles y reasignar usuarios

from sqlalchemy.orm import Session
from app.db.database import get_db, create_tables
from app.repositories.user_repository import UserRepository
from app.repositories.hotel_repository import HotelRepository
from app.schemas.hotel import HotelCreate
# Importar todos los modelos para evitar errores de relaciones
from app.models import hotel, user, refresh_token
from app.models.hotel import Hotel
from app.models.user import User

def migrate_hotels_and_users():
    """Migrar hoteles y reasignar usuarios"""
    # Obtener sesión de base de datos
    db_gen = get_db()
    db: Session = next(db_gen)
    
    try:
        print("🔄 Iniciando migración de hoteles...")
        
        # Repositorios
        hotel_repo = HotelRepository(db)
        user_repo = UserRepository(db)
        
        # 1. Obtener todos los usuarios antes de eliminar hoteles
        print("📋 Obteniendo usuarios existentes...")
        all_users = db.query(User).all()
        print(f"✅ Encontrados {len(all_users)} usuarios")
        
        # 2. Eliminar todos los hoteles existentes (hard delete)
        print("🗑️ Eliminando hoteles existentes...")
        existing_hotels = db.query(Hotel).all()
        for hotel in existing_hotels:
            db.delete(hotel)
        db.commit()
        print(f"✅ Eliminados {len(existing_hotels)} hoteles")
        
        # 3. Crear nuevos hoteles
        print("🏨 Creando nuevos hoteles...")
        hotels_data = [
            {
                "name": "Talbot Hotels Corporativo",
                "location": "Santiago",
                "address": "El Bosque Norte #0440",
                "rooms": 120,
                "manager": "Administrador",
                "phone": "+56 2 2345 6789",
                "description": "Hotel corporativo Talbot en Santiago",
                "status": "active"
            },
            {
                "name": "Hyatt Centric Las Condes Santiago",
                "location": "Santiago",
                "address": "Enrique Foster 30",
                "rooms": 85,
                "manager": "Administrador",
                "phone": "+56 2 2345 6790",
                "description": "Hotel Hyatt Centric en Las Condes",
                "status": "active"
            },
            {
                "name": "Holiday Inn Aeropuerto Terminal Santiago",
                "location": "Santiago",
                "address": "Armando Cortinez Norte #2150",
                "rooms": 95,
                "manager": "Administrador",
                "phone": "+56 2 2345 6791",
                "description": "Holiday Inn cerca del aeropuerto de Santiago",
                "status": "active"
            },
            {
                "name": "Holiday Inn Express Las Condes Santiago",
                "location": "Santiago",
                "address": "Av. Vitacura #2929",
                "rooms": 110,
                "manager": "Administrador",
                "phone": "+56 2 2345 6792",
                "description": "Holiday Inn Express en Las Condes",
                "status": "active"
            },
            {
                "name": "Holiday Inn Express Concepción",
                "location": "Concepción",
                "address": "San Andrés #38",
                "rooms": 75,
                "manager": "Administrador",
                "phone": "+56 41 224 0000",
                "description": "Holiday Inn Express en Concepción",
                "status": "active"
            },
            {
                "name": "Holiday Inn Express Temuco",
                "location": "Temuco",
                "address": "Av. Ortega #01800",
                "rooms": 90,
                "manager": "Administrador",
                "phone": "+56 45 221 2000",
                "description": "Holiday Inn Express en Temuco",
                "status": "active"
            },
            {
                "name": "Holiday Inn Express Iquique",
                "location": "Iquique",
                "address": "Av. Arturo Prat #1690",
                "rooms": 65,
                "manager": "Administrador",
                "phone": "+56 57 241 0000",
                "description": "Holiday Inn Express en Iquique",
                "status": "active"
            },
            {
                "name": "Holiday Inn Express Antofagasta",
                "location": "Antofagasta",
                "address": "Av. Grecia #1490",
                "rooms": 80,
                "manager": "Administrador",
                "phone": "+56 55 245 8000",
                "description": "Holiday Inn Express en Antofagasta",
                "status": "active"
            }
        ]
        
        created_hotels = []
        for hotel_data in hotels_data:
            hotel_create = HotelCreate(**hotel_data)
            new_hotel = hotel_repo.create(hotel_create)
            created_hotels.append(new_hotel)
            print(f"✅ Hotel creado: {hotel_data['name']} (ID: {new_hotel.id})")
        
        # 4. Reasignar usuarios a los nuevos hoteles
        print("👥 Reasignando usuarios a nuevos hoteles...")
        if created_hotels and all_users:
            # Distribuir usuarios entre los hoteles disponibles
            hotel_count = len(created_hotels)
            for i, user in enumerate(all_users):
                # Asignar hotel de forma circular
                assigned_hotel = created_hotels[i % hotel_count]
                user.hotel_id = assigned_hotel.id
                print(f"✅ Usuario {user.username} asignado a {assigned_hotel.name}")
            
            db.commit()
            print(f"✅ {len(all_users)} usuarios reasignados exitosamente")
        
        print("\n🎉 Migración completada exitosamente!")
        print(f"📊 Resumen:")
        print(f"   - Hoteles eliminados: {len(existing_hotels)}")
        print(f"   - Hoteles creados: {len(created_hotels)}")
        print(f"   - Usuarios reasignados: {len(all_users)}")
        
    except Exception as e:
        print(f"❌ Error durante la migración: {str(e)}")
        db.rollback()
        raise
    finally:
        db.close()

if __name__ == "__main__":
    migrate_hotels_and_users()